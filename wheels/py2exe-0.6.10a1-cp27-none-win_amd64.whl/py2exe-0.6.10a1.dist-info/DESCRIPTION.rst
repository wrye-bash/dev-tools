This package is a distutils extension to build
standalone Windows executable programs from
Python scripts.


